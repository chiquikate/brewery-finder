<h1>What's New</h1>

Version 1.0

- Added contents and initial design.
- Added brewery list from API.
- Added search and filter functionality.

Version 1.1

- Added individual page which shows details about the selected brewery.
- Added brewery-mapping, which integrates Google Maps into the brewery details page
- Improved initial design
